local Framework = nil

if Config.Framework == "qb" or Config.Framework == "auto" then
    Framework = exports['qb-core']:GetCoreObject()
elseif Config.Framework == "esx" then
    Framework = exports['es_extended']:getSharedObject()
end

local cooldowns = {}

RegisterNetEvent("a_gang:startRobbery", function(gang)
    local src = source
    local xPlayer = Framework.Functions.GetPlayer(src)

    if not Config.Gangs[gang] then
        print(("Invalid gang: %s"):format(gang))
        return
    end

    local gangData = Config.Gangs[gang]

    -- Check cooldown
    if cooldowns[gang] and os.time() < cooldowns[gang] then
        local remaining = math.ceil((cooldowns[gang] - os.time()) / 60)
        TriggerClientEvent('chat:addMessage', src, { args = { "SYSTEM", ("The stash is still cooling down! Try again in %d minutes."):format(remaining) } })
        return
    end

    cooldowns[gang] = os.time() + Config.Robbery.cooldown * 60

    TriggerClientEvent("a_gang:notifyRobbery", -1, src, gangData.enter.coords)
    Wait(Config.Robbery.time * 60000)

    local reward = math.random(Config.Robbery.reward.min, Config.Robbery.reward.max)
    xPlayer.Functions.AddMoney("cash", reward)
    TriggerClientEvent('chat:addMessage', src, { args = { "SYSTEM", ("You robbed the stash and got $%d!"):format(reward) } })
end)
