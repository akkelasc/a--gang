fx_version 'cerulean'
game 'gta5'

description 'Gang job system for Fivem using predefined configuration'

shared_script 'config.lua'

server_scripts {
    'server/server.lua'
}

client_scripts {
    'client/client.lua'
}

dependencies {
    'qb-core',
    'es_extended'
}
