Config = {}

Config.UseTarget = false -- ox_target

Config.UseRPName = true

Config.Framework = "auto" -- "auto" | "qb" | "esx"

-- stash robbery
Config.Robbery = {
    enabled = true,

    blackListedWeapons = {
        `weapon_unarmed`,
        `weapon_flashlight`,
        `weapon_wrench`,
        `weapon_nightstick`
    },

    time = 5,      -- minutes

    required = 4,  -- how many gang members required online

    cooldown = 10, -- minutes

    reward = {
        item = "cash",
        min = 300,
        max = 700
    },

    blip = {
        enabled = true,
        shortRange = false,

        scale = 0.7,
        colour = 1,
        sprite = 478
    }
}


Config.Distances = {
    marker = 5,    -- marker shows
    interact = 1.5 -- can press [E] & textui shows
}

Config.ShopTiers = {
    ["1"] = {
        { name = "phone", price = 500 }
    }
}

Config.Shells = { -- offset finder => https://github.com/loaf-scripts/loaf_offsetfinder
    ["example_shell"] = {
        hash = `example_shell`,

        door = {
            coords = vec4(0, 0, 0, 0),
            targetOptions = {
                size = vec3(1, 1, 1),
            },
            marker = {
                size = 1,
                type = 1,
                color = { r = 255, g = 0, b = 0, a = 200 },
            }
        },

        stash = {
            coords = {
                vec3(0, 0, 0)
            },
            targetOptions = {
                size = vec3(1, 1, 1),
            },
            marker = {
                size = 1,
                type = 1,
                color = { r = 255, g = 0, b = 0, a = 200 },
            }
        },
        shop = {
            coords = {
                vec3(0, 0, 0)
            },
            targetOptions = {
                size = vec3(1, 1, 1),
            },
            marker = {
                size = 1,
                type = 1,
                color = { r = 255, g = 0, b = 0, a = 200 },
            }
        },
        bossmenu = {
            coords = {
                vec3(0, 0, 0),
            },
            targetOptions = {
                size = vec3(1, 1, 1),
            },
            marker = {
                size = 1,
                type = 1,
                color = { r = 255, g = 0, b = 0, a = 200 },
            }
        },
        clothing = {
            coords = {
                vec3(0, 0, 0),
            },
            targetOptions = {
                size = vec3(1, 1, 1),
            },
            marker = {
                size = 1,
                type = 1,
                color = { r = 255, g = 0, b = 0, a = 200 },
            }
        },
    }
}

Config.Gangs = {
    ["example"] = {
        blip = { -- only gang members can see blip
            shortRange = false,

            scale = 0.7,
            colour = 7,
            sprite = 492,

            text = "Example Gang"
        },

        shell = "example_shell",
        shop = {
            tier = "1",
            minGrade = 0,
        },
        stash = {
            weight = 50000,
            slots = 40,
            minGrade = 0,
        },
        enter = {
            coords = vec3(582.33, -1132.92, 10.12),
            targetOptions = {
                size = vec3(1, 1, 1),
            },
            marker = {
                size = 1,
                type = 1,
                color = { r = 255, g = 0, b = 0, a = 200 },
            }
        }
    },
    ["example2"] = {
        stash = {
            weight = 50000,
            slots = 40,
            minGrade = 0,
            coords = {
                vec3(572.76, -1146.25, 10.08)
            },
            targetOptions = {
                size = vec3(1, 1, 1)
            },
            marker = {
                size = 1,
                type = 1,
                color = { r = 255, g = 0, b = 0, a = 200 },
            }
        },
        shop = {
            coords = {
                vec3(576.41, -1132.09, 10.12)
            },
            tier = "1",
            minGrade = 0,
            targetOptions = {
                size = vec3(1, 1, 1)
            },
            marker = {
                size = 1,
                type = 1,
                color = { r = 255, g = 0, b = 0, a = 200 },
            }
        },
        bossmenu = {
            coords = {
                vec3(579.4781, -1131.1077, 10.1225)
            },
            targetOptions = {
                size = vec3(1, 1, 1)
            },
            marker = {
                size = 1,
                type = 1,
                color = { r = 255, g = 0, b = 0, a = 200 },
            }
        },
        clothing = {
            coords = {
                vec3(576.41, -1132.09, 10.12)
            },
            targetOptions = {
                size = vec3(1, 1, 1)
            },
            marker = {
                size = 1,
                type = 1,
                color = { r = 255, g = 0, b = 0, a = 200 },
            }
        }
    }
}
